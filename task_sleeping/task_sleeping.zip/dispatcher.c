#include "datatypes.h"

void task_yield (){
    task_switch (&dispatcher);
}

task_t* scheduler(){
    task_t *aux = (task_t *)t_queue->next;
    task_t *task_run = (task_t *)t_queue->next;
    while(aux != (task_t *)t_queue){
        if(aux->prio_dinamic <= task_run->prio_dinamic){
            task_run = aux;
            aux->prio_dinamic--;
        }else{
            aux->prio_dinamic--;
        }
        aux = aux->next;
    }
    task_run->prio_dinamic = task_run->prio_static;

    return (task_t*) task_run;
}

void dispatcher_body (){ // dispatcher é uma tarefa
    task_t* next;
    while ( user_task  > 1 ){
        if( sleeping_queue != NULL){
            task_t * aux = (task_t *) sleeping_queue;
            int total = queue_size(sleeping_queue);
            int i;
            for(i = 0; i < total; i++){
                  if(systime() > aux->t_awakening){
                      sleeping_queue =  sleeping_queue->next;
                      queue_remove((queue_t **) &sleeping_queue, (queue_t *) aux);
                      queue_append((queue_t **) &t_queue, (queue_t *) aux);
                      //aux->status = 0;
                      aux = (task_t *) sleeping_queue;
                  }else{
                      aux = aux->next;
                  }
            }
         }
        next = scheduler() ;  // scheduler é uma função
        if (next->task_nivel != 0){
             // ações antes de lançar a tarefa "next", se houverem
	    dispatcher.task_activations++; // incrementa o contador de ativacoes da tarefa dispatcher
            next->task_activations++;// incrementa o contador de ativacoes da tarefa atual
            task_switch (next) ; // transfere controle para a tarefa "next"
            // ações após retornar da tarefa "next", se houverem
        }
    }
    task_exit(1) ; // encerra a tarefa dispatcher
}
